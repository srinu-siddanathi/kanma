<header>
    <div class="container-fluid">
        <div class="row py-3 border-bottom align-items-center g-0">
            <div class="col-sm-4 col-lg-2 text-center text-sm-start">
                <div class="main-logo">
                    <a href="{{ route('home') }}">
                        <img src="{{ asset('images/logo.png') }}" alt="logo" class="img-fluid">
                    </a>
                </div>
            </div>

            <div class="col-sm-4 col-lg-2 pe-lg-2">
                <div class="location-selector d-flex align-items-center bg-light p-2 rounded-4" data-bs-toggle="modal"
                    data-bs-target="#locationModal" style="cursor: pointer;">
                    <svg width="24" height="24" class="me-2">
                        <use xlink:href="#location"></use>
                    </svg>
                    <div class="fw-medium text-truncate" id="selected-address-label">
                        Select your location
                    </div>
                    <svg width="16" height="16" class="ms-auto">
                        <use xlink:href="#chevron-down"></use>
                    </svg>
                </div>
            </div>

            <div class="col-sm-6 offset-sm-2 offset-md-0 col-lg-6 d-none d-lg-block ps-lg-2">
                <div class="search-bar bg-light p-2 my-2 rounded-4">
                    <form id="search-form" class="d-flex align-items-center position-relative" action="{{ route('search') }}" method="get" style="gap:0;">
                        <input type="text" class="form-control border-0 bg-transparent" name="q" id="header-search-input" autocomplete="off" placeholder="Search for more than 20,000 products">
                        <button type="submit" class="btn p-0 ms-n2" style="background: none; border: none;">
                            <svg width="24" height="24">
                                <use xlink:href="#search"></use>
                            </svg>
                        </button>
                        <div id="search-suggestions" class="position-absolute w-100 bg-white border rounded shadow-sm mt-1" style="z-index: 1050; display: none; left: 0; top: 100%;"></div>
                    </form>
                </div>
            </div>

            <div class="col-sm-8 col-lg-2 d-flex justify-content-end gap-3 align-items-center mt-4 mt-sm-0">
                <div class="header-element ms-4">
                    <a href="#" class="cart-toggle">
                        <div class="cart-icon-wrapper position-relative d-inline-block">
                            <svg width="24" height="24"><use xlink:href="#cart"></use></svg>
                            <span class="cart-badge position-absolute top-0 start-100 translate-middle">
                                <span class="cart-count">0</span>
                            </span>
                        </div>
                    </a>
                </div>
                @auth
                <div class="header-element ms-3 dropdown">
                    <a href="#" class="dropdown-toggle d-flex align-items-center" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false" title="Account" aria-label="Account">
                        <i class="bi bi-person-circle" style="font-size: 1.8rem;"></i>
                        <span class="ms-2 d-none d-sm-inline">{{ auth()->user()->name }}</span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="{{ route('profile.edit') }}">Profile</a></li>
                        <li><a class="dropdown-item" href="{{ route('orders') }}">My Orders</a></li>
                        <li><a class="dropdown-item" href="{{ route('addresses.manage') }}">Manage Addresses</a></li>
                        <li>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="dropdown-item">Logout</button>
                            </form>
                        </li>
                    </ul>
                </div>
                @else
                <li>
                    <a href="#" class="btn btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#loginModal">Login</a>
                </li>
                @endauth
            </div>
        </div>
    </div>

    <!-- Navigation Bar -->
    @hasSection('hide-menu')
        {{-- Menu is hidden on this page --}}
    @else
    <div class="container-fluid">
        <div class="row py-3">
            <div class="d-flex  justify-content-center justify-content-sm-between align-items-center">
                <nav class="main-menu d-flex navbar navbar-expand-lg">
                    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                        data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar"
                        aria-labelledby="offcanvasNavbarLabel">
                        <div class="offcanvas-header justify-content-center">
                            <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <div class="offcanvas-body">
                            <select class="filter-categories border-0 mb-0 me-5">
                                <option>Shop by Departments</option>
                                <option>Groceries</option>
                                <option>Drinks</option>
                                <option>Chocolates</option>
                            </select>
                            <ul class="navbar-nav justify-content-end menu-list list-unstyled d-flex gap-md-3 mb-0">
                                <li class="nav-item">
                                    <a href="{{ route('home') }}" class="nav-link">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a href="{{ route('shop') }}" class="nav-link">Shop</a>
                                </li>
                                <li class="nav-item">
                                    <a href="{{ route('about') }}" class="nav-link">About Us</a>
                                </li>
                                <li class="nav-item active">
                                    <a href="{{ route('cart') }}" class="nav-link">Cart</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a href="{{ route('checkout') }}" class="nav-link">Checkout</a>
                                </li>
                                <li class="nav-item">
                                    <a href="{{ route('product.show', ['id' => 1]) }}" class="nav-link">Product View</a>
                                </li>
                                <!-- <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" role="button" id="pages"
                                        data-bs-toggle="dropdown" aria-expanded="false">Pages</a>
                                    <ul class="dropdown-menu" aria-labelledby="pages">
                                        <li><a href="index.html" class="dropdown-item">About Us </a></li>
                                        <li><a href="index.html" class="dropdown-item">Shop </a></li>
                                        <li><a href="index.html" class="dropdown-item">Single Product </a></li>
                                        <li><a href="index.html" class="dropdown-item">Cart </a></li>
                                        <li><a href="index.html" class="dropdown-item">Checkout </a></li>
                                        <li><a href="index.html" class="dropdown-item">Blog </a></li>
                                        <li><a href="index.html" class="dropdown-item">Single Post </a></li>
                                        <li><a href="index.html" class="dropdown-item">Styles </a></li>
                                        <li><a href="index.html" class="dropdown-item">Contact </a></li>
                                        <li><a href="index.html" class="dropdown-item">Thank You </a></li>
                                        <li><a href="index.html" class="dropdown-item">My Account </a></li>
                                        <li><a href="index.html" class="dropdown-item">404 Error </a></li>
                                    </ul>
                                </li> -->

                            </ul>

                        </div>

                    </div>
            </div>
        </div>
    </div>
    @endif
</header>

<!-- Location Modal -->
<div class="modal fade" id="locationModal" tabindex="-1" aria-labelledby="locationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="locationModalLabel">Choose your delivery location</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="location-search mb-4">
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-end-0">
                            <svg width="24" height="24">
                                <use xlink:href="#location"></use>
                            </svg>
                        </span>
                        <input type="text" class="form-control border-start-0"
                            placeholder="Enter your delivery location">
                    </div>
                </div>
                <div class="detect-location d-flex align-items-center mb-4">
                    <button class="btn btn-outline-primary btn-sm">
                        <svg width="16" height="16" class="me-2">
                            <use xlink:href="#location-crosshairs"></use>
                        </svg>
                        Detect current location
                    </button>
                    <span class="text-muted ms-2 small">Using GPS</span>
                </div>
                <div class="saved-locations">
                    <h6 class="mb-3">Saved Locations</h6>
                    <div class="list-group">
                        @forelse($userAddresses as $address)
                            <a href="#"
                               class="list-group-item list-group-item-action"
                               onclick="selectDeliveryAddress({{ $address->id }}, this)"
                               data-address="{{ htmlspecialchars(json_encode([
                                   'id' => $address->id,
                                   'type' => ucfirst($address->address_type),
                                   'line1' => $address->address_line1,
                                   'line2' => $address->address_line2,
                                   'city' => $address->city,
                                   'state' => $address->state,
                                   'postal_code' => $address->postal_code,
                                   'country' => $address->country,
                               ]), ENT_QUOTES, 'UTF-8') }}">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">{{ ucfirst($address->address_type) }}</h6>
                                    @if($address->is_default)
                                        <small class="text-muted">Default</small>
                                    @endif
                                </div>
                                <p class="mb-1 small text-muted">
                                    {{ $address->address_line1 }}
                                    @if($address->address_line2)
                                        , {{ $address->address_line2 }}
                                    @endif
                                    , {{ $address->city }}, {{ $address->state }} {{ $address->postal_code }}
                                    , {{ $address->country }}
                                </p>
                            </a>
                        @empty
                            <div class="text-muted small">No saved addresses found.</div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0">
                <h5 class="modal-title" id="loginModalLabel">Login to your account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="loginForm" class="px-3">
                    @csrf
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" required autofocus>
                        <div class="invalid-feedback" id="emailError"></div>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <svg width="16" height="16" class="password-toggle-icon">
                                    <use xlink:href="#eye"></use>
                                </svg>
                            </button>
                        </div>
                        <div class="invalid-feedback" id="passwordError"></div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember" name="remember">
                            <label class="form-check-label" for="remember">
                                Remember me
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>

                    <div class="text-center mb-4">
                        <span class="text-muted">or login with</span>
                    </div>

                    <div class="d-flex gap-2 mb-4">
                        <a href="#" class="btn btn-outline-secondary w-50">
                            <svg width="18" height="18" class="me-2">
                                <use xlink:href="#google"></use>
                            </svg>
                            Google
                        </a>
                        <a href="#" class="btn btn-outline-secondary w-50">
                            <svg width="18" height="18" class="me-2">
                                <use xlink:href="#facebook"></use>
                            </svg>
                            Facebook
                        </a>
                    </div>

                    <div class="text-center">
                        <span class="text-muted">Don't have an account?</span>
                        <a href="#" class="text-decoration-none">Register now</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));

    // Toggle password visibility
    document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        
        // Toggle eye icon
        const icon = this.querySelector('use');
        icon.setAttribute('xlink:href', type === 'password' ? '#eye' : '#eye-slash');
    });

    // Handle form submission
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Reset previous error messages
        document.getElementById('emailError').textContent = '';
        document.getElementById('passwordError').textContent = '';
        
        // Get CSRF token from the form
        const token = document.querySelector('input[name="_token"]').value;
        
        if (!token) {
            console.error('CSRF token not found');
            document.getElementById('emailError').textContent = 'Security token missing. Please refresh the page and try again.';
            return;
        }

        try {
            const response = await fetch('{{ route("ajax.login") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'Accept': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                credentials: 'same-origin',
                body: JSON.stringify({
                    email: document.getElementById('email').value,
                    password: document.getElementById('password').value,
                    remember: document.getElementById('remember').checked,
                    _token: token
                })
            });

            const data = await response.json();
            console.log('Login response:', data); // Debug log
            
            if (!response.ok) {
                console.error('Login error:', {
                    status: response.status,
                    data: data
                });
                
                if (data.errors) {
                    if (data.errors.email) {
                        document.getElementById('emailError').textContent = data.errors.email[0];
                    }
                    if (data.errors.password) {
                        document.getElementById('passwordError').textContent = data.errors.password[0];
                    }
                } else {
                    const errorMessage = data.message || data.debug || 'Login failed. Please try again.';
                    document.getElementById('emailError').textContent = errorMessage;
                }
                return;
            }

            if (data.status === 'success') {
                loginModal.hide();
                window.location.reload();
            } else {
                document.getElementById('emailError').textContent = data.message || 'Login failed. Please try again.';
            }
        } catch (error) {
            console.error('Login error:', error);
            document.getElementById('emailError').textContent = 'An error occurred. Please try again.';
        }
    });

    var saved = localStorage.getItem('selectedAddress');
    if (saved) {
        var address = JSON.parse(saved);
        var label = address.type + ': ' + address.line1;
        if (address.line2) label += ', ' + address.line2;
        label += ', ' + address.city + ', ' + address.state + ' ' + address.postal_code + ', ' + address.country;
        document.getElementById('selected-address-label').textContent = label;
    }

    const input = document.getElementById('header-search-input');
    const suggestionsBox = document.getElementById('search-suggestions');
    let debounceTimeout;
    input.addEventListener('input', function() {
        clearTimeout(debounceTimeout);
        const query = this.value.trim();
        if (query.length < 2) {
            suggestionsBox.style.display = 'none';
            suggestionsBox.innerHTML = '';
            return;
        }
        debounceTimeout = setTimeout(() => {
            fetch(`/api/search-suggestions?q=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    if (Object.keys(data).length === 0) {
                        suggestionsBox.style.display = 'none';
                        suggestionsBox.innerHTML = '';
                        return;
                    }
                    suggestionsBox.innerHTML = Object.entries(data).map(([id, name]) =>
                        `<div class='px-3 py-2 suggestion-item' style='cursor:pointer;' data-id='${id}' data-name='${name}'>${name}</div>`
                    ).join('');
                    suggestionsBox.style.display = 'block';
                });
        }, 200);
    });
    suggestionsBox.addEventListener('mousedown', function(e) {
        if (e.target.classList.contains('suggestion-item')) {
            input.value = e.target.dataset.name;
            suggestionsBox.style.display = 'none';
            // Option 1: Submit the form
            input.form.submit();
            // Option 2: To go directly to product page, use:
            // window.location.href = `/product/${e.target.dataset.id}`;
        }
    });
    document.addEventListener('click', function(e) {
        if (!suggestionsBox.contains(e.target) && e.target !== input) {
            suggestionsBox.style.display = 'none';
        }
    });
});

function selectDeliveryAddress(addressId, el) {
    var modal = bootstrap.Modal.getInstance(document.getElementById('locationModal'));
    modal.hide();
    var addressData = el.getAttribute('data-address');
    if (addressData) {
        var address = JSON.parse(addressData);
        var label = address.type + ': ' + address.line1;
        if (address.line2) label += ', ' + address.line2;
        label += ', ' + address.city + ', ' + address.state + ' ' + address.postal_code + ', ' + address.country;
        document.getElementById('selected-address-label').textContent = label;
        localStorage.setItem('selectedAddress', addressData);
    }
}
</script>
@endpush