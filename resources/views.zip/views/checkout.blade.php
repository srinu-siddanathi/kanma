@extends('layouts.main')

@section('content')
<section class="py-5 bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1 class="display-4 mb-3">Checkout</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{ route('cart') }}">Cart</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="card-title mb-4">Order Summary</h3>
                        
                        <!-- Cart Items -->
                        <div class="order-items mb-4">
                            @foreach($items as $item)
                            <div class="d-flex align-items-center mb-3 pb-3 border-bottom">
                                <img src="{{ asset($item['image_path']) }}" alt="{{ $item['product_name'] }}" class="img-thumbnail" style="width: 80px; height: 80px; object-fit: cover;">
                                <div class="ms-3 flex-grow-1">
                                    <h6 class="mb-1">{{ $item['product_name'] }}</h6>
                                    <p class="mb-0 text-muted">Quantity: {{ $item['quantity'] }} × ₹{{ number_format($item['price'], 2) }}</p>
                                </div>
                                <div class="text-end">
                                    <span class="fw-bold">₹{{ number_format($item['total'], 2) }}</span>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <!-- Order Totals -->
                        <div class="order-totals mb-4">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal</span>
                                <span>₹{{ number_format($total, 2) }}</span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Shipping</span>
                                <span>₹0.00</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-4">
                                <strong>Total</strong>
                                <strong class="text-primary">₹{{ number_format($total, 2) }}</strong>
                            </div>
                        </div>

                        <!-- Payment Options -->
                        <div class="payment-options mb-4">
                            <h5 class="mb-3">Delivery Address</h5>
                            <div class="mb-3">
                                <textarea class="form-control" name="delivery_address" id="delivery_address" rows="3" required placeholder="Enter your delivery address">{{ auth()->user()->address }}</textarea>
                            </div>

                            <h5 class="mb-3">Payment Method</h5>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="payment_method" id="cod" value="cod" checked>
                                <label class="form-check-label" for="cod">
                                    Cash on Delivery (COD)
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" id="razorpay" value="razorpay">
                                <label class="form-check-label" for="razorpay">
                                    Pay with Razorpay
                                </label>
                            </div>
                        </div>

                        <!-- Checkout Button -->
                        <button type="button" class="btn btn-primary w-100" id="checkout-btn">
                            Proceed to Checkout
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModalLabel">Login Required</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Please login to continue with your checkout.</p>
                <div class="d-grid gap-2">
                    <a href="{{ route('login', ['redirect' => route('checkout')]) }}" class="btn btn-primary">Login</a>
                    <a href="{{ route('register', ['redirect' => route('checkout')]) }}" class="btn btn-outline-primary">Register</a>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkoutBtn = document.getElementById('checkout-btn');
    const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
    const isAuthenticated = {{ auth()->check() ? 'true' : 'false' }};

    checkoutBtn.addEventListener('click', function() {
        if (!isAuthenticated) {
            loginModal.show();
            return;
        }

        const deliveryAddress = document.getElementById('delivery_address').value.trim();
        if (!deliveryAddress) {
            alert('Please enter your delivery address');
            return;
        }

        const selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked').value;
        
        if (selectedPaymentMethod === 'razorpay') {
            // Initialize Razorpay
            const options = {
                key: "{{ config('services.razorpay.key') }}",
                amount: "{{ $total * 100 }}", // Amount in paise
                currency: "INR",
                name: "{{ config('app.name') }}",
                description: "Order Payment",
                order_id: "{{ $razorpayOrder->id ?? '' }}",
                handler: function (response) {
                    console.log('Razorpay payment successful', response);
                    
                    // Show loading state
                    checkoutBtn.disabled = true;
                    checkoutBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
                    
                    // Create form and submit
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = "{{ route('checkout.store') }}";

                    // Add CSRF token
                    const csrfToken = document.createElement('input');
                    csrfToken.type = 'hidden';
                    csrfToken.name = '_token';
                    csrfToken.value = "{{ csrf_token() }}";
                    form.appendChild(csrfToken);

                    // Add delivery address
                    const addressInput = document.createElement('input');
                    addressInput.type = 'hidden';
                    addressInput.name = 'delivery_address';
                    addressInput.value = deliveryAddress;
                    form.appendChild(addressInput);

                    // Add payment method
                    const paymentMethod = document.createElement('input');
                    paymentMethod.type = 'hidden';
                    paymentMethod.name = 'payment_method';
                    paymentMethod.value = 'razorpay';
                    form.appendChild(paymentMethod);

                    // Add Razorpay payment details
                    const razorpayPaymentId = document.createElement('input');
                    razorpayPaymentId.type = 'hidden';
                    razorpayPaymentId.name = 'razorpay_payment_id';
                    razorpayPaymentId.value = response.razorpay_payment_id;
                    form.appendChild(razorpayPaymentId);

                    const razorpayOrderId = document.createElement('input');
                    razorpayOrderId.type = 'hidden';
                    razorpayOrderId.name = 'razorpay_order_id';
                    razorpayOrderId.value = response.razorpay_order_id;
                    form.appendChild(razorpayOrderId);

                    const razorpaySignature = document.createElement('input');
                    razorpaySignature.type = 'hidden';
                    razorpaySignature.name = 'razorpay_signature';
                    razorpaySignature.value = response.razorpay_signature;
                    form.appendChild(razorpaySignature);

                    // Add form to document and submit
                    document.body.appendChild(form);
                    console.log('Submitting form with payment details');
                    
                    // Submit form using fetch to handle the response
                    fetch(form.action, {
                        method: 'POST',
                        body: new FormData(form),
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Server response:', data);
                        if (data.redirect) {
                            window.location.href = data.redirect;
                        } else {
                            alert('Payment successful! Redirecting to orders page...');
                            window.location.href = "{{ route('orders') }}";
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred. Please try again.');
                        checkoutBtn.disabled = false;
                        checkoutBtn.innerHTML = 'Proceed to Checkout';
                    });
                },
                prefill: {
                    name: "{{ auth()->user()->first_name ?? '' }} {{ auth()->user()->last_name ?? '' }}",
                    email: "{{ auth()->user()->email ?? '' }}",
                    contact: "{{ auth()->user()->phone ?? '' }}"
                },
                theme: {
                    color: "#3399cc"
                },
                modal: {
                    ondismiss: function() {
                        console.log('Payment modal dismissed');
                    }
                }
            };

            try {
                const rzp = new Razorpay(options);
                rzp.on('payment.failed', function (response) {
                    console.error('Payment failed', response.error);
                    alert('Payment failed. Please try again.');
                });
                rzp.open();
            } catch (error) {
                console.error('Error initializing Razorpay', error);
                alert('Error initializing payment. Please try again.');
            }
        } else {
            // For COD, create and submit form
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = "{{ route('checkout.store') }}";

            // Add CSRF token
            const csrfToken = document.createElement('input');
            csrfToken.type = 'hidden';
            csrfToken.name = '_token';
            csrfToken.value = "{{ csrf_token() }}";
            form.appendChild(csrfToken);

            // Add delivery address
            const addressInput = document.createElement('input');
            addressInput.type = 'hidden';
            addressInput.name = 'delivery_address';
            addressInput.value = deliveryAddress;
            form.appendChild(addressInput);

            // Add payment method
            const paymentMethod = document.createElement('input');
            paymentMethod.type = 'hidden';
            paymentMethod.name = 'payment_method';
            paymentMethod.value = 'cod';
            form.appendChild(paymentMethod);

            document.body.appendChild(form);
            form.submit();
        }
    });
});
</script>

<!-- Test Mode Instructions -->
<div class="modal fade" id="testModeModal" tabindex="-1" aria-labelledby="testModeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="testModeModalLabel">Test Mode Instructions</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>You are currently in test mode. Use the following test card details:</p>
                <div class="card mb-3">
                    <div class="card-body">
                        <h6>For Successful Payment:</h6>
                        <ul class="list-unstyled">
                            <li><strong>Card Number:</strong> 4111 1111 1111 1111</li>
                            <li><strong>Expiry:</strong> Any future date</li>
                            <li><strong>CVV:</strong> Any 3 digits</li>
                            <li><strong>Name:</strong> Any name</li>
                        </ul>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h6>For Failed Payment:</h6>
                        <ul class="list-unstyled">
                            <li><strong>Card Number:</strong> 4111 1111 1111 1111</li>
                            <li><strong>Expiry:</strong> Any past date</li>
                            <li><strong>CVV:</strong> Any 3 digits</li>
                            <li><strong>Name:</strong> Any name</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Add a button to show test mode instructions -->
<button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#testModeModal">
    <i class="bi bi-info-circle"></i> Test Mode Instructions
</button>
@endpush
@endsection 